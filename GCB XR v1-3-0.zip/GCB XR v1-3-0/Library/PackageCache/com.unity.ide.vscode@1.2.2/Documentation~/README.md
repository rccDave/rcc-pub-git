# Code Editor Package for Visual Studio Code

This package is not intended to be modified by users.
Nor does it provide any api intended to be included in user projects.